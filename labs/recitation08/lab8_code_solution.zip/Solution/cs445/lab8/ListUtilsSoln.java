package cs445.lab8;

import java.util.Iterator;

public class ListUtilsSoln {

    public static <T> void printList(ListInterface<T> list) {
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            System.out.print(it.next() + " ");
        }
        System.out.println();
    }

    public static void removeShortStrings(ListInterface<String> list, int limit) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            if (it.next().length() < limit) {
                it.remove();
            }
        }
    }

    public static void main(String[] args) {
		ListInterface<String> myList = new ArrayList<String>();

		myList.add("Apples");
		myList.add("are");
		myList.add("so");
		myList.add("good");
		myList.add("...");
		myList.add("in");
		myList.add("fact");
		myList.add("I");
		myList.add("eat");
		myList.add("them");
		myList.add("when");
		myList.add("I");
		myList.add("write");
		myList.add("programs");

        // prints "Apples are so good ... in fact I eat them when I write programs"
		System.out.println("Original list:");
		printList(myList);

        //prints "Apples write programs"
		System.out.println("Strings of length 5 or greater:");
		removeShortStrings(myList, 5);
		printList(myList);
    }
}

