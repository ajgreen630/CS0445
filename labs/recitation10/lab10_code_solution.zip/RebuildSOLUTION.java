import cs445.binary.BinaryTree;
import java.util.Iterator;

class RebuildBinaryTree {

    // driver program to test
    public static void main(String args[]) {
        // Example from slides
        String preorder = "BZRFTUHOL";
        String inorder = "RZTFUBOHL";
        BinaryTree<Character> tree = rebuildTree(inorder, preorder);

        if (tree != null) {
            // Use iterators to confirm
            System.out.print("Preorder: ");
            Iterator<Character> it = tree.getPreorderIterator();
            while(it.hasNext()) {
                System.out.print(it.next() + " ");
            }
            System.out.println("");

            System.out.print("Inorder: ");
            it = tree.getInorderIterator();
            while(it.hasNext()) {
                System.out.print(it.next() + " ");
            }
            System.out.println("");
        } else {
            System.out.println("Returned tree was null");
        }
    }

    /* Recursive function to build the binary tree from
       inorder traversal inorder and preorder traversal preorder. */
    static BinaryTree<Character> rebuildTree(String inorder, String preorder) {
        if (preorder.length() == 0) {
            return null;
        }

        Character rootData = preorder.charAt(0);

        /* Else find the index of this node in Inorder traversal */
        int inorderIndex = inorder.indexOf(rootData);
        String leftInorder = inorder.substring(0, inorderIndex);
        String rightInorder = inorder.substring(inorderIndex + 1);

        String leftPreorder = preorder.substring(1, inorderIndex + 1);
        String rightPreorder = preorder.substring(inorderIndex + 1);

        BinaryTree<Character> leftSub = rebuildTree(leftInorder, leftPreorder);
        BinaryTree<Character> rightSub = rebuildTree(rightInorder, rightPreorder);

        return new BinaryTree<Character>(rootData, leftSub, rightSub);
    }
}

