import cs445.binary.BinaryTree;
import java.util.Iterator;

class RebuildBinaryTree {

    // driver program to test
    public static void main(String args[]) {
        // Example from slides
        String preorder = "BZRFTUHOL";
        String inorder = "RZTFUBOHL";
        BinaryTree<Character> tree = rebuildTree(inorder, preorder);

        if (tree != null) {
            // Use iterators to confirm
            System.out.print("Preorder: ");
            Iterator<Character> it = tree.getPreorderIterator();
            while(it.hasNext()) {
                System.out.print(it.next() + " ");
            }
            System.out.println("");

            System.out.print("Inorder: ");
            it = tree.getInorderIterator();
            while(it.hasNext()) {
                System.out.print(it.next() + " ");
            }
            System.out.println("");
        } else {
            System.out.println("Returned tree was null");
        }
    }

    /* Recursive function to build the binary tree from
       inorder traversal inorder and preorder traversal preorder. */
    static BinaryTree<Character> rebuildTree(String inorder, String preorder) {
        return null;
    }
}

