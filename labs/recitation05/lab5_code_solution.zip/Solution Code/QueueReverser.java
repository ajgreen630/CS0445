package cs445.lab5;

public class QueueReverser {
	public static <T> void reverseQueue(QueueInterface<T> queue) {
		// TODO: Make the stack to use for reversing the queue
		StackInterface<T> stack = new LinkedStack<T>();
		
		// TODO: Move all the elements from the queue to the stack
		
		while(!queue.isEmpty()) {
			stack.push(queue.dequeue());
		}
		
		// TODO: Move all of the elements back into the queue, reversing the original order
		
		while(!stack.isEmpty()) {
			queue.enqueue(stack.pop());
		}
	}
}