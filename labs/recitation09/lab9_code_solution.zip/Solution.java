package cs445.lab9;

import java.util.Arrays;

public class Lab9 {
    /**
     * Reverses the order of the objects in an array, using divide and conquer
     * recursion. This method is just a wrapper for the helper function.
     */
    public static <T> void reverse(T[] a) {
        // First, create an auxiliary array for the reversal to happen
        @SuppressWarnings("unchecked")
        T[] aux = (T[])new Object[a.length];
        // Then, call the helper function that takes bounds
        reverse(a, aux, 0, a.length);
    }

    /**
     * Reverses the order of the objects in an array, using divide and conquer
     * recursion. This method is the recursive helper function.
     */
    private static <T> void reverse(T[] a, T[] aux, int start, int end) {
        // Recursive case: if there is more than 1 element left
        if (end - start > 1) {
            // First, compute the mid
            int mid = (start+end)/2;
            // Reverse the left half
            reverse(a, aux, start, mid);
            // Reverse the right half
            reverse(a, aux, mid, end);
            // Swap the left and right halves.
            // NOTE: All the work is done in the recombine! The base case is
            // empty, and the split is a simple "cut in half".
            swapRegions(a, aux, start, mid, end);
        }
        // Implicit base case: if there is only 1 element (no change needed)
    }

    /**
     * Swaps two regions within an array. Everything from [start, mid) is
     * swapped with everything in [mid, end). This is the method that does all
     * the work in reverse!
     */
    private static <T> void swapRegions(T[] a, T[] aux, int start, int mid, int end) {
        // Initialize a variable for where we are copying into in aux
        int i = start;
        // Copy everything from mid to end from a to aux
        for (int j = mid; j < end; j++) {
            aux[i++] = a[j];
        }
        // Copy everything from start to mid from a to aux
        for (int j = start; j < mid; j++) {
            aux[i++] = a[j];
        }
        // Copy everything from start to end back from aux to a
        for (int j = start; j < end; j++) {
            a[j] = aux[j];
        }
    }

    /**
     * Replaces each instance of character before with character after within
     * str, and returns the resulting string. This uses divide and conquer
     * recursion.
     */
    public static String replace(String str, char before, char after) {
        // Recursive case: if there is more than 1 character left
        if (str.length() > 1) {
            // Compute the midpoint
            int mid = str.length() / 2;
            // Replace before with after in the left half
            String leftResult = replace(str.substring(0, mid), before, after);
            // Replace before with after in the right half
            String rightResult = replace(str.substring(mid, str.length()), before, after);
            // Concatenate the two halves and return
            return leftResult + rightResult;
        }
        // Base case: if there is only 1 character left
        else {
            // If the remaining character is before,
            if (str.charAt(0) == before) {
                // then return after as a string
                return Character.toString(after);
            } else {
                // otherwise, just return the string as-is
                return str;
            }
            // NOTE: All the work is done in this base case! The divide and the
            // recombine are just doing substring and concatenation.
        }
    }
}

