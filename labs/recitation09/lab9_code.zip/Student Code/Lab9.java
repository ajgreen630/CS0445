package cs445.lab9;

public class Lab9 {
    /**
     * Reverses the order of the objects in an array, using divide and conquer
     * recursion.
     */
    public static <T> void reverse(T[] a) {
        // TODO: Complete this method
    }

    /**
     * Replaces each instance of character before with character after within
     * str, and returns the resulting string. This uses divide and conquer
     * recursion.
     */
    public static String replace(String str, char before, char after) {
        // TODO: Complete this method
        return "";
    }
}

